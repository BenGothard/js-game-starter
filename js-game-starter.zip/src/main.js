const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
canvas.width = 400;
canvas.height = 400;
ctx.fillStyle = 'teal';
ctx.fillRect(0, 0, canvas.width, canvas.height);