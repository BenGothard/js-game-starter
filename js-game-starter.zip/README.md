# JS Game Starter

## 🚀 Setup
\`\`\`bash
chmod +x setup.sh
./setup.sh
\`\`\`

When ready for local development:
\`\`\`bash
npm install
npm run dev
\`\`\`

GitHub Pages deployment is automated to \`gh-pages\` branch.
